import { Worker } from "bullmq";
import { redis } from "./config/redis.js";
import { aggregateToday } from "./processors/aggregateToday.js";

new Worker(
  "analytics",
  async (job) => {
    // For demo simplicity, we aggregate today's stats on any job.
    // You will later optimize to aggregate per event/purchase and add idempotency.
    await aggregateToday();
    return { ok: true, name: job.name };
  },
  { connection: redis }
);

console.log("[worker] listening on queue: analytics");
