# High-Performance Product Analytics API

Production-grade backend demonstrating performance engineering:
- Fastify + JSON schema validation
- PostgreSQL with indexes
- Redis caching
- BullMQ async jobs
- Rate limiting
- Docker + Nginx
- Load testing (Autocannon)

## Quick start
```bash
cd infra
docker compose up --build
```

## Endpoints
- Health: `GET /health`
- Ready: `GET /ready`
- Swagger UI: `GET /docs`
- OpenAPI: `GET /openapi.yaml`

## Load testing
Examples (run on host):
```bash
npx autocannon -c 200 -d 20 http://localhost/health
```

## Architecture
See `architecture.md` and `MASTER_BUILD_PLAN.md`.
